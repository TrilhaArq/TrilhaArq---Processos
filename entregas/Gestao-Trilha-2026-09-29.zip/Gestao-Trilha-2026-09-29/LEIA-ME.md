# Gestão Trilha — cópia de segurança de 29/09/2026

App oficial: https://claude.ai/artifact/N5fGJZBumZy7dyN57w7e8o (versão 8, com Gestor de Projetos, Cadastros e Financeiro).
Código também no GitHub: TrilhaArq/TrilhaArq---Processos, pasta `gestao-trilha/` (branch claude/projeto-gestor-arquitetura-9pvm13).

## O que tem aqui

1. **1-app/** — os arquivos do app exatamente como estão publicados (index.html, estilo.css, nucleo.js, logo.png e
   modulos/*.js). Os dados (projetos, horas, financeiro) não ficam nos arquivos: ficam no banco do próprio link.
2. **2-regras-claude/gestao-trilha/** — a skill do app (SKILL.md + referencias/CONTRATO.md e REGRAS.md).
   Copie a pasta `gestao-trilha` inteira para a sua pasta de skills/regras do Claude. É ela que ensina qualquer chat
   novo a mexer no app sem estragar nada.
3. **3-processo-trilha/** — o mapeamento do processo de projeto (base do Gestor), a lista de ajustes e decisões,
   os textos dos termos e a proposta do app.

## Como continuar num chat novo

- Com a skill instalada, basta pedir: "no app Gestão Trilha, quero …". O Claude lê a versão publicada, altera,
  testa e republica no mesmo link (os dados continuam).
- Sem a skill: anexe `CONTRATO.md`, `REGRAS.md` e os arquivos de `1-app/`, e diga para publicar no mesmo link
  (passando a URL acima).
- Um chat por vez publicando no app.
